#!/system/bin/sh

R="\033[31m"
G="\033[32m"
Y="\033[33m"
B="\033[34m"
P="\033[35m"
C="\033[36m"
W="\033[37m"
N="\033[0m"

line() {
  echo -e "${B}────────────────────────────────────${N}"
}

echo
line
echo -e "${P}===== DISPLAY REFRESH RATE =====${N}"

_HZ=$(dumpsys display 2>/dev/null \
| grep -oE 'fps=[0-9]+(\.[0-9]+)?' \
| cut -d= -f2 \
| sort -nu \
| tail -n 1 \
| awk '{printf("%.0f\n", $1)}')

[ -z "$_HZ" ] && _HZ="UNKNOWN"

echo -e "${G}Refresh Rate : ${W}${_HZ} Hz${N}"

echo
line
echo -e "${P}===== SURFACEFLINGER APP DURATION (ns) =====${N}"
echo -e "${G}Early App            : ${W}$(getprop debug.sf.early.app.duration)${N}"
echo -e "${G}EarlyGl App          : ${W}$(getprop debug.sf.earlyGl.app.duration)${N}"
echo -e "${G}Late App             : ${W}$(getprop debug.sf.late.app.duration)${N}"
echo -e "${G}HFPS Early App       : ${W}$(getprop debug.sf.high_fps.early.app.duration)${N}"
echo -e "${G}HFPS EarlyGl App     : ${W}$(getprop debug.sf.high_fps.earlyGl.app.duration)${N}"
echo -e "${G}HFPS Late App        : ${W}$(getprop debug.sf.high_fps.late.app.duration)${N}"

echo
line
echo -e "${P}===== SURFACEFLINGER SF DURATION (ns) =====${N}"
echo -e "${Y}Early SF             : ${W}$(getprop debug.sf.early.sf.duration)${N}"
echo -e "${Y}EarlyGl SF           : ${W}$(getprop debug.sf.earlyGl.sf.duration)${N}"
echo -e "${Y}Late SF              : ${W}$(getprop debug.sf.late.sf.duration)${N}"
echo -e "${Y}HFPS Early SF        : ${W}$(getprop debug.sf.high_fps.early.sf.duration)${N}"
echo -e "${Y}HFPS EarlyGl SF      : ${W}$(getprop debug.sf.high_fps.earlyGl.sf.duration)${N}"
echo -e "${Y}HFPS Late SF         : ${W}$(getprop debug.sf.high_fps.late.sf.duration)${N}"

echo
line
echo -e "${P}===== VSYNC APP PHASE OFFSET (ns) =====${N}"
echo -e "${C}Early App Offset         : ${W}$(getprop debug.sf.early_app_phase_offset_ns)${N}"
echo -e "${C}EarlyGl App Offset       : ${W}$(getprop debug.sf.earlyGl_app_phase_offset_ns)${N}"
echo -e "${C}Late App Offset          : ${W}$(getprop debug.sf.late_app_phase_offset_ns)${N}"
echo -e "${C}HFPS Early App Offset    : ${W}$(getprop debug.sf.high_fps_early_app_phase_offset_ns)${N}"
echo -e "${C}HFPS EarlyGl App Offset  : ${W}$(getprop debug.sf.high_fps_earlyGl_app_phase_offset_ns)${N}"
echo -e "${C}HFPS Late App Offset     : ${W}$(getprop debug.sf.high_fps_late_app_phase_offset_ns)${N}"

echo
line
echo -e "${P}===== VSYNC SF PHASE OFFSET (ns) =====${N}"
echo -e "${C}Early SF Offset          : ${W}$(getprop debug.sf.early_phase_offset_ns)${N}"
echo -e "${C}EarlyGl SF Offset        : ${W}$(getprop debug.sf.earlyGl_phase_offset_ns)${N}"
echo -e "${C}Late SF Offset           : ${W}$(getprop debug.sf.late_phase_offset_ns)${N}"
echo -e "${C}HFPS Early SF Offset     : ${W}$(getprop debug.sf.high_fps_early_phase_offset_ns)${N}"
echo -e "${C}HFPS EarlyGl SF Offset   : ${W}$(getprop debug.sf.high_fps_earlyGl_phase_offset_ns)${N}"
echo -e "${C}HFPS Late SF Offset      : ${W}$(getprop debug.sf.high_fps_late_phase_offset_ns)${N}"

line
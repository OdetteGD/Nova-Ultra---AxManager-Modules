#!/system/bin/sh

alias SP="setprop"
alias STS="settings"
alias C="cmd"

SP debug.sf.use_phase_offsets_as_durations ""
SP debug.sf.disable_backpressure ""
SP debug.sf.latch_unsignaled ""
SP debug.sf.max_frame_latency ""
SP debug.sf.frame_rate_multiple_threshold ""

SP debug.sf.use_frame_rate_priority ""
SP debug.sf.early.app.duration ""
SP debug.sf.late.app.duration ""
SP debug.sf.high_fps.early.app.duration ""
SP debug.sf.high_fps.late.app.duration ""

SP debug.sf.early.sf.duration ""
SP debug.sf.late.sf.duration ""
SP debug.sf.high_fps.early.sf.duration ""
SP debug.sf.high_fps.late.sf.duration ""

SP debug.sf.early.app.phase_offset_ns ""
SP debug.sf.late.app.phase_offset_ns ""
SP debug.sf.high_fps.early.app.phase_offset_ns ""
SP debug.sf.high_fps.late.app.phase_offset_ns ""

SP debug.sf.early.sf.phase_offset_ns ""
SP debug.sf.late.sf.phase_offset_ns ""
SP debug.sf.high_fps.early.sf.phase_offset_ns ""
SP debug.sf.high_fps.late.sf.phase_offset_ns ""

SP debug.choreographer.low_latency ""
SP debug.choreographer.zero_jitter ""
SP debug.choreographer.skipwarning ""

SP debug.input.lowlatency ""
SP debug.touchscreen.latency.scale ""
SP debug.sf.default_touch_timer_ms ""
SP debug.sf.set_touch_timer_ms ""

SP debug.sf.boost_sf_on_touch ""
SP debug.sf.high_speed_scroll_factor ""
SP debug.sf.defer_refresh_rate_when_off ""

SP debug.sf.dejitterfps ""
SP debug.sf.mDejitterfps ""

SP debug.sf.showfps ""
SP debug.sf.showupdates ""
SP debug.sf.showcpu ""
SP debug.sf.showbackground ""
SP debug.sf.show_debug_log ""
SP debug.sf.show_debug_log.layer ""
SP debug.sf.show_refresh_rate_overlay_spinner ""
SP debug.sf.show_refresh_rate_overlay_render_rate ""
SP debug.sf.show_refresh_rate_overlay_in_middle ""
SP debug.sf.show_refresh_rate_detail_log ""

SP debug.hwui.use_buffer_age ""
SP debug.hwui.enable_buffer_queue_pacing ""
SP debug.hwui.skip_empty_damage ""
SP debug.hwui.use_partial_updates ""

SP debug.egl.swapinterval ""

SP debug.sf.default_refresh_rate ""
SP debug.sf.refresh_default_rate ""
SP debug.sf.scroll_boost_refreshrate ""
SP debug.sf.touch_boost_refreshrate ""
SP debug.hwui.profile.maxframes ""

SP debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold ""
SP debug.oculus.refreshRate ""
SP debug.OVRPlugin.systemDisplayFrequency ""

STS delete system preferred_refresh_rate
STS delete system min_refresh_rate
STS delete system max_refresh_rate
STS delete system peak_refresh_rate
STS delete system default_refresh_rate
STS delete system refresh_default_rate
STS delete system low_power_refresh_rate
STS delete secure user_refresh_rate
STS delete system user_refresh_rate
STS delete system min_render_frame_rate
STS delete system peak_render_frame_rate

cmd display clear-user-preferred-display-mode

C device_config put game_overlay default_fps_override 0
C device_config put game_overlay enable_frame_pacing true

inputflinger reset

STS delete system miui_refresh_rate
STS delete secure miui_refresh_rate
STS delete system thermal_limit_refresh_rate

STS delete secure coloros_screen_refresh_rate
STS delete secure oplus_customize_screen_refresh_rate
STS delete secure oplus_customize_min_refresh_rate
STS delete secure oplus_customize_peak_refresh_rate
STS delete global oneplus_screen_refresh_rate
STS delete global oneplus_screen_resolution_adjust
STS delete secure refresh_rate_mode
STS delete system db_screen_rate
STS delete global 6ecb9657_screen_refresh_rate
STS delete system power_save_pre_refresh_state
STS delete system power_save_screen_refresh_rate
STS delete system power_save_coloros_screen_refresh_rate

STS delete system last_tran_refresh_mode_in_refresh_setting
STS delete system tran_refresh_mode
STS delete system tran_need_recovery_refresh_mode
STS delete system tran_need_recovery_refresh_rate

STS delete global vivo_screen_refresh_rate_mode
STS delete system gamecube_frame_interpolation
STS delete system gamewatch_game_target_fps

cmd notification post -S bigtext -t '🅱️-FramePacing' '🛑' " uninstalled"
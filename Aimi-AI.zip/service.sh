#!/system/bin/sh

alias SP="setprop"
alias STS="settings"
alias C="cmd"

SOC="$(getprop ro.board.platform \
    | tr '[:upper:]' '[:lower:]')"

HW="$(getprop ro.hardware \
    | tr '[:upper:]' '[:lower:]')"

BRAND="$(getprop ro.product.brand \
    | tr '[:upper:]' '[:lower:]')"

MANU="$(getprop ro.product.manufacturer \
    | tr '[:upper:]' '[:lower:]')"

NAME="$(getprop ro.product.device \
    | tr '[:upper:]' '[:lower:]')"

MODEL="$(getprop ro.product.model \
    | tr '[:upper:]' '[:lower:]')"

FPSI="$(dumpsys display 2>/dev/null \
    | grep -oE 'fps=[0-9]+(\.[0-9]+)?' \
    | cut -d= -f2 \
    | sort -nu \
    | tail -n1 \
    | awk '{printf("%.0f\n",$1)}')"

[ -z "$FPSI" ] && FPSI=60

refresh_rate="$(dumpsys display | grep -Eo 'fps=[0-9]+' | cut -d= -f2 | sort -n | tail -n1)"
[ -z "$refresh_rate" ] && refresh_rate=60

frame_ns=$((1000000000 / refresh_rate))

app_duration=$((frame_ns * 95 / 100))
sf_duration=$((frame_ns * 85 / 100))

app_phase_offset=$((-app_duration))
sf_phase_offset=$((-sf_duration))

SP debug.sf.early.app.duration "$app_duration"
SP debug.sf.earlyGl.app.duration "$app_duration"
SP debug.sf.high_fps.early.app.duration "$app_duration"
SP debug.sf.high_fps.earlyGl.app.duration "$app_duration"
SP debug.sf.high_fps.late.app.duration "$app_duration"
SP debug.sf.late.app.duration "$app_duration"
SP debug.sf.early.sf.duration "$sf_duration"
SP debug.sf.earlyGl.sf.duration "$sf_duration"
SP debug.sf.high_fps.early.sf.duration "$sf_duration"
SP debug.sf.high_fps.earlyGl.sf.duration "$sf_duration"
SP debug.sf.high_fps.late.sf.duration "$sf_duration"
SP debug.sf.late.sf.duration "$sf_duration"
SP debug.sf.earlyGl_app_phase_offset_ns "$app_phase_offset"
SP debug.sf.early_app_phase_offset_ns "$app_phase_offset"
SP debug.sf.high_fps_earlyGl_app_phase_offset_ns "$app_phase_offset"
SP debug.sf.high_fps_early_app_phase_offset_ns "$app_phase_offset"
SP debug.sf.high_fps_late_app_phase_offset_ns "$app_phase_offset"
SP debug.sf.late_app_phase_offset_ns "$app_phase_offset"
SP debug.sf.earlyGl_phase_offset_ns "$sf_phase_offset"
SP debug.sf.early_phase_offset_ns "$sf_phase_offset"
SP debug.sf.high_fps_earlyGl_phase_offset_ns "$sf_phase_offset"
SP debug.sf.high_fps_early_phase_offset_ns "$sf_phase_offset"
SP debug.sf.high_fps_late_phase_offset_ns "$sf_phase_offset"
SP debug.sf.late_phase_offset_ns "$sf_phase_offset"

CMD display set-match-content-frame-rate-pref 2
STS put --user 0 secure match_content_frame_rate 2

STS put system min_refresh_rate "$FPSI"
STS put system peak_refresh_rate "$FPSI"
STS put system preferred_refresh_rate "$FPSI"

STS put system min_render_frame_rate "$FPSI"
STS put system peak_render_frame_rate "$FPSI"

STS put secure user_refresh_rate "$FPSI"
STS put system user_refresh_rate "$FPSI"

if echo "$BRAND $MANU $NAME $MODEL" | grep -Eq "xiaomi|redmi|poco"; then
    STS put --user 0 system miui_refresh_rate "$FPSI"
    STS put --user 0 secure miui_refresh_rate "$FPSI"
fi

if echo "$BRAND $MANU $NAME $MODEL" | grep -Eq "oppo|realme|oneplus|oplus"; then
    STS put --user 0 secure coloros_screen_refresh_rate 0
    STS put --user 0 secure refresh_rate_mode 7
fi

if echo "$BRAND $MANU $NAME $MODEL" | grep -Eq "itel|infinix|tecno"; then
    STS put --user 0 system tran_refresh_mode "$FPSI"
fi

if echo "$BRAND $MANU $NAME $MODEL" | grep -Eq "vivo|iqoo"; then
    STS put --user 0 global vivo_screen_refresh_rate_mode "$FPSI"
fi